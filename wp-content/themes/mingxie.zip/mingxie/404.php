<?php get_template_parts( array( 'parts/shared/html-header', 'parts/shared/header' ) ); ?>
<h2>Page not found</h2>
<?php get_template_parts( array( 'parts/shared/footer','parts/shared/html-footer' ) ); ?>